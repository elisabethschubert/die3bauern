---
title: "Kontakt"
---

In dem Kontakt Abschnitt von **Vorstellung** kannst die aktuelle Zeit in einer belibigen Zeitzone angezeigt werden.

Somit können Besucher darauf hingewiesen werden, wann sie mit einer Antwort rechnen können. Die Zeitzone wird einfach über die Konfiguarationdatei gewählt.
