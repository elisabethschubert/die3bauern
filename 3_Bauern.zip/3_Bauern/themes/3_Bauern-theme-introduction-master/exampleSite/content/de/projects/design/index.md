---
title: "Design"
weight: 2
resources:
    - src: plant.jpg
      params:
          weight: -100
---

Dieses Theme wurde von [Victoria Drake](https://victoria.dev) entwickelt. Guck es dir an! 💪

Wenn du es für deine Webseite verwenden willst, guck dir den Abschnitt unten auf der Hauptseite an. 👍
