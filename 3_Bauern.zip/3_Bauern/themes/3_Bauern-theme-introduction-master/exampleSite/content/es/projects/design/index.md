---
title: "Diseño"
weight: 2
resources:
    - src: plant.jpg
      params:
          weight: -100
---
Este tema fue diseñado por [Victoria Drake](https://victoria.dev). Ve, explora! 💪

Si deseas usarlo en tu sitio web, revisa la sección al final de la página principal. 👍
