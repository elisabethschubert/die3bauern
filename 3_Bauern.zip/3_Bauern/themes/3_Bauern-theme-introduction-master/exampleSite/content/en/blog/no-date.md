---
title: "Undated post"
tags: ["words"]
---

I was born yesterday, tomorrow.
