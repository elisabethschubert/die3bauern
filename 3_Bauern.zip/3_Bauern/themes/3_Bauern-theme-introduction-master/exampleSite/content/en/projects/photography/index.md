---
title: "Photography"
weight: 1
---

## Sometimes I take pictures

This project is about the pictures I take. Sometimes, they are pictures of cats.
