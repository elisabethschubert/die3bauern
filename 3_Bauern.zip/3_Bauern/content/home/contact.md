---
title: "Kontakt"
draft: true
weight: 0
---

Per Mail erreichen Sie uns unter: die_3_bauern@gmail.com

Telefonisch sind wir unter 0664/123 456 78 erreichbar
