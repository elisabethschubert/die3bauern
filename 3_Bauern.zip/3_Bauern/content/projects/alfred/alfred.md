---
title: "Alfred" # Title of your project
date: 2019-12-01T15:58:36+01:00
weight: 1 # Order in which to show this project on the home page
external_link: "" # Optional external link instead of modal
resources:
    - src: alfred.jpg
      params:
          weight: -100 # Optional weighting for a specific image in this project folder
draft: true
---
Alfred Huber ist ein sehr gesprächiger Mann, pflegt seinen Garten mit voller Hingabe und vertreibt seine acht verschiedenen Apfelsorten für sein Leben gern.

Seine Kinder helfen ihm tatkräftig am Hof und schnappen sich gerne während der Arbeit einen saftigen und süßlich riechenden Apfel. Alfred hat viele Stammkunden und zaubert ihnen täglich ein Lächeln ins Gesicht, wenn er sie wieder mit einem netten Begrüßungs-Gedicht begrüßt.
