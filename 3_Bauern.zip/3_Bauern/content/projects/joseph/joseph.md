---
title: "Joseph" # Title of your project
date: 2019-12-01T15:57:41+01:00
weight: 3 # Order in which to show this project on the home page
external_link: "" # Optional external link instead of modal
resources:
    - src: joseph.jpg
      params:
          weight: -100 # Optional weighting for a specific image in this project folder
draft: true
---
Auch Joseph Krispel beeindruckt seine Kunden mit seiner Passion zu seinem Gemüse. Karotten, Kartoffeln, Paprika und Kürbisse - eine große Auswahl und für jedermanns Geschmack etwas dabei. Aus seinen Kürbissen stellt er das grüne Gold, steirisches Kürbiskernöl genannt, her. Die Etiketten für die Kernöl-Flaschen designt er selbst und diese sprechen für sich, denn er hat kreative Ideen und bringt seine liebsten Sprüche auf seinen Flaschen an. Doch nicht nur auf Grund der Etiketten ist das Kernöl so schnell ausverkauft, sondern auch wegen des einzigartigen Geschmacks.
