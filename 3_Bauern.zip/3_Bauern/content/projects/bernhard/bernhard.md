---
title: "Bernhard" # Title of your project
date: 2019-12-01T15:59:14+01:00
weight: 2 # Order in which to show this project on the home page
external_link: "" # Optional external link instead of modal
resources:
    - src: bernhard.jpg
      params:
          weight: -100 # Optional weighting for a specific image in this project folder
draft: true
---
Bernhard Wiedner ist auch ein Bauer mit Leidenschaft. Seine Beeren, wie Heidel-, Him-, Stachel- und Kiwibeeren, und Tomaten lassen jedem Kunden das Wasser im Mund zusammenlaufen. Weiters kann er seine Kunden mit Säften begeistern. Eines seiner beliebtesten Produkte ist das Heidelbeerkonzentrat, das mit Wasser vermischt zu einem süßen Saft wird. Durch sein Verkaufstalent konnte er einen großen Kunden, die Volksschule des Ortes, gewinnen, welche er nunmehr seit einem Jahr mit seinen Fruchtkonzentraten beliefert.
